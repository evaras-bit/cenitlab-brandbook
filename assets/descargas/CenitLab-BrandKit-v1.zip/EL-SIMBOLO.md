# El símbolo — los dos arcos y el punto cenit

<p align="center">
  <img src="logos/png/isotipo-512.png" alt="Isotipo Cenit Lab" width="220">
</p>

> **La máquina procesa. La persona decide.**
> **Cenit es el punto donde los dos trabajan juntos.**

El isotipo de Cenit Lab es **“el punto cenit”**: dos trazos ascienden desde la
base y se funden en un único punto de luz —el punto más alto, el cenit—. No es
un adorno: es el resumen de lo que hace el estudio.

---

## Los dos arcos

| Arco | Color | Significa | Es… |
|------|-------|-----------|-----|
| **Cálido** | Oro Cenit `#C6A35B` | **La persona** | intuición, criterio, contexto — *decide* |
| **Frío** | Azul Estelar `#8FA8CE` | **La máquina** | cómputo, escala, velocidad — *procesa* |

Una persona entiende el contexto, pero no puede revisar diez mil datos.
Una máquina revisa diez mil datos, pero no entiende el contexto.
Los dos arcos son esas dos inteligencias subiendo a la vez.

## El punto cenit

El **punto cenit** —degradado oro→azul, con halo y destello— es donde los dos
arcos **se encuentran y se funden**. Es la fusión humano–máquina: la nueva
capacidad, el punto más alto. Es, literalmente, *el punto donde los dos trabajan
juntos*.

## Las curvas: sin fricción

Los trazos son **curvas suaves, sin aristas**. Esa forma es intencional:

> **El lujo real es vivir sin fricción.**

Trabajamos como un **cisne**: en la superficie, una experiencia serena y sin
esfuerzo; debajo del agua, una capa de IA y machine learning operando 24/7,
invisible, para que todo simplemente funcione. Por eso el símbolo no tiene
ángulos duros: la elegancia serena arriba, la potencia por debajo.

---

## La regla que no cambia

Cualquier rediseño, animación o adaptación **debe preservar**:

1. **Dos trazos** —uno cálido, uno frío— que **convergen** en un punto.
2. El **punto cenit arriba** (nunca rotado: el cenit siempre es el punto más alto).
3. **Curvas sin aristas** (sin fricción).

El significado —persona + máquina que se funden en un punto de luz— **no se
toca**. Los colores, tamaños y fondos se adaptan según las reglas de uso; la
metáfora, no.

---

*Fuentes: `IDENTIDAD.md`, `CLAUDE.md` §2 y el manifiesto “Why” de Cenit Lab.
Para construcción geométrica exacta del mark (viewBox, paths, gradientes), ver
`CLAUDE.md` §4. Para reglas de uso completas, abre el brandbook.*
