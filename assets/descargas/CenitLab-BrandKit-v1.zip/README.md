# Cenit Lab — Brand Kit v1

Kit de marca completo de **Cenit Lab** para desarrollos y colaboradores.
*Designing the Future of Human–Machine Collaboration.*

**Versión web (con buscador):** https://brandbook.cenitlab.cl — el manual online
tiene menú hamburguesa con búsqueda para encontrar cualquier sección al instante.
Se despliega en EasyPanel (ver `site/_DESPLEGAR-EN-EASYPANEL.md` en el paquete de sitio).

**Skill para Claude Code:** existe el skill `marca-cenitlab` (aplicar / auditar /
servir / generar marca en cualquier proyecto Cenit Lab). Se mantiene sincronizado
con este kit — dispáralo con `/marca-cenitlab` o pídele "aplica la marca CenitLab".

---

## Empieza por aquí
- **[EL-SIMBOLO.md](EL-SIMBOLO.md)** — qué significan los dos arcos y el punto cenit (léelo primero).
- **[brandbook/CenitLab-BrandBook.pdf](brandbook/CenitLab-BrandBook.pdf)** — el manual completo en PDF.
- **[brandbook/cenit-lab-brandbook.html](brandbook/cenit-lab-brandbook.html)** — el manual interactivo (ábrelo en el navegador).
- **[CLAUDE.md](CLAUDE.md)** — sistema de marca detallado (geometría, tokens, reglas). Contexto técnico.
- **[IDENTIDAD.md](IDENTIDAD.md)** — quién es Cenit Lab, unidades y propósito.

## Logos

### `logos/svg/` — vectores editables
Isotipo, horizontal, horizontal invertido, vertical y app-icon. El texto usa las
fuentes de marca (se ven bien en navegador y apps con las fuentes instaladas).

### `logos/svg-outlined/` — vectores con texto en trazos ⭐
Los mismos logos pero con el texto convertido a **paths**. Úsalos para
**impresión, corte, bordado o cualquier app de terceros** — se ven idénticos sin
necesidad de instalar fuentes.

### `logos/png/` — mapas de bits listos para usar
| Archivo | Uso |
|---|---|
| `isotipo-256/512/1024.png` | isotipo transparente |
| `isotipo-512-bone.png` · `isotipo-512-indigo.png` | isotipo sobre fondo claro / oscuro |
| `logo-horizontal-1120/1680.png` | lockup horizontal (fondo claro / transparente) |
| `logo-horizontal-rev-*.png` | lockup invertido (para fondos oscuros) |
| `logo-vertical-*.png` | lockup vertical apilado + tagline |
| `app-icon-512/1024.png` | icono de app |
| `cenit-lab-avatar-*.png` · `cenit-lab-logo-workspace-*.png` | avatares y logos de workspace |

## Iconos y favicon — `favicon/`
Set completo: `favicon.ico` (16/32/48), `favicon.svg`, `apple-touch-icon.png`,
`icon-192.png`, `icon-512.png`, `icon-512-maskable.png` y `og-image.png`
(preview para redes/WhatsApp).

## Design tokens — `design-tokens/`
Fuente de verdad para desarrollo:
- `tokens.css` → variables CSS (`--gold`, `--indigo`, `--steel`, …).
- `tokens.json` → mismos tokens machine-readable.

## Paleta rápida
| | HEX | |
|---|---|---|
| Índigo Cenit | `#0D1430` | primario / fondos oscuros |
| Oro Cenit | `#C6A35B` | acento cálido · **la persona** |
| Azul Estelar | `#8FA8CE` | acento frío · **la máquina** |
| Hueso | `#F4F1E9` | fondo claro |

## Tipografía
- **Space Grotesk** — titulares y wordmark (600).
- **IBM Plex Sans** — cuerpo e interfaz (300–600).
- **IBM Plex Mono** — datos, eyebrows y códigos de unidad (`CL · AI`), UPPERCASE con tracking.

---

*Reglas de uso, construcción del isotipo y tono de voz: ver el brandbook (HTML o PDF).
El significado del símbolo no debe cambiar — ver `EL-SIMBOLO.md`.*
