# CLAUDE.md — Cenit Lab · Sistema de Marca

> Contexto de proyecto para Claude Code. Este documento describe la identidad visual
> de **Cenit Lab** y cómo trabajar sobre ella. Léelo completo antes de modificar assets.

---

## 1. Qué es Cenit Lab

Estudio de ingeniería tecnológica (separado de Mod Journey SPA, del mismo fundador, **Eduardo Varas**).
Enfocado en inteligencia artificial, sistemas de datos y creación de nuevos negocios digitales.

- **Tagline:** *Designing the Future of Human–Machine Collaboration.*
- **Propósito:** la próxima plataforma tecnológica no será una app ni un dispositivo, sino la
  integración continua entre inteligencia humana e IA. Construir *“la capa de inteligencia sobre
  la cual operarán las empresas y las personas del futuro.”*
- **Filosofía de marca:** *“el lujo real es vivir sin fricción”* — metáfora del cisne (experiencia
  serena en la superficie, IA/ML operando 24/7 por debajo).

### Unidades de negocio (sub-marcas)
| Código | Unidad | Foco |
|--------|--------|------|
| `CL · AI` | Cenit Lab AI | Agentes, LLMs, Machine Learning, Automation |
| `CL · DT` | Cenit Lab Data | Data platforms, Analytics, Warehousing, BI |
| `CL · SY` | Cenit Lab Systems | Software, Apps, Integraciones, APIs, Infraestructura |
| `CL · XP` | Cenit Lab Experience | Customer Experience, Hospitality Tech, AI Interfaces |
| `CL · VN` | Cenit Lab Ventures | Incubación y creación de startups propias |

---

## 2. Concepto del isotipo (NO cambiar el significado)

El isotipo es **“el punto cenit”**: dos trazos ascienden y se funden en un único punto de luz.

- **Trazo cálido (oro) = lo humano** — intuición, criterio, contexto.
- **Trazo frío (azul estelar) = la máquina** — cómputo, escala, velocidad.
- **Punto cenit (degradado oro→azul) = la fusión** — la nueva capacidad, el punto más alto.
- **Curvas suaves, sin aristas = sin fricción** — la elegancia serena del cisne.

Cualquier rediseño debe preservar esta dualidad cálido/frío que converge en un punto.

---

## 3. Design tokens

Fuente de verdad: `design-tokens/tokens.css` (CSS custom properties) y `design-tokens/tokens.json`.

### Color
| Token | Nombre | HEX | Uso |
|-------|--------|-----|-----|
| `--indigo` | Índigo Cenit | `#0D1430` | Primario · superficies oscuras, texto |
| `--indigo-2` | Índigo Profundo | `#16204A` | Degradados, profundidad |
| `--indigo-deep` | — | `#0B1026` | Fondo más oscuro (footer, hero deep) |
| `--gold` | Oro Cenit | `#C6A35B` | Acento cálido · **lo humano** |
| `--gold-lt` | Oro claro | `#D8B86E` | Trazo humano en fondo oscuro / brillos |
| `--gold-dp` | Oro profundo | `#A8843B` | Eyebrows sobre fondo claro |
| `--steel` | Azul Estelar | `#8FA8CE` | Acento frío · **la máquina** |
| `--steel-lt` | Azul claro | `#A6BEDE` | Trazo máquina en fondo oscuro |
| `--bone` | Hueso | `#F4F1E9` | Fondo claro, texto invertido |
| `--bone-2` | Hueso 2 | `#FBF9F3` | Fondo claro alterno |
| `--ink` | Tinta | `#15192B` | Texto cuerpo sobre claro |
| `--mist` | Niebla | `#6B7385` | Texto secundario |
| `--line` | Línea | `#E3DDD1` | Bordes/hairlines sobre claro |

### Tipografía
- **Display / titulares / wordmark:** `Space Grotesk` (geométrica, futura). Pesos 400–700; titulares y wordmark en **600**.
- **Cuerpo / interfaz:** `IBM Plex Sans` (pesos 300–600). Elegida a propósito: IBM Plex fue diseñada
  para expresar la relación humano–máquina → narrativa de marca en el propio tipo. Cuerpo **300**, énfasis **500**.
- **Datos / etiquetas / código:** `IBM Plex Mono` (400–500). Uso en eyebrows, códigos de unidad (`CL · AI`),
  data; siempre UPPERCASE con tracking ~`.2em`.
- Carga vía Google Fonts:
  `https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=IBM+Plex+Sans:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap`

### Wordmark
`CENIT` + `LAB`, Space Grotesk 600, UPPERCASE, letter-spacing tracked (~`.06em`–`4px`).
`LAB` siempre en oro (`--gold` sobre claro, `--gold-lt` sobre oscuro). `CENIT` en tinta (claro) o hueso (oscuro).

---

## 4. Geometría del isotipo (viewBox 0 0 120 120)

Para recrear o ajustar el mark por código. Strokes `stroke-width="7.5"`, `stroke-linecap="round"`, `fill="none"`.

```
Trazo humano  (gold)  : M28 98 C 33 54, 50 30, 60 22
Trazo máquina (steel) : M92 98 C 87 54, 70 30, 60 22   (espejo en x=60)
Halo                  : circle cx60 cy20 r10.5  stroke gold  width 1.4  opacity .4
Punto cenit           : circle cx60 cy20 r6     fill url(#z)  [linear gold→steel, x 52→68]
Destello (glint)      : circle cx58 cy18 r1.8   fill #FBF6EA  opacity .9
Resplandor (glow)     : circle cx60 cy20 r18    fill url(#g)  [radial gold .4 → 0]
```

- **Versión invertida (fondo oscuro):** strokes y halo usan `--gold-lt` / `--steel-lt`.
- **Versión monocromo:** todos los strokes + punto en `currentColor`; sin glow ni glint.

---

## 5. Inventario de archivos

```
cenit-lab-brand/
├── CLAUDE.md                                  ← este archivo
├── README.md
├── design-tokens/
│   ├── tokens.css                             ← variables CSS (fuente de verdad)
│   └── tokens.json                            ← tokens machine-readable
├── logos/
│   ├── cenit-lab-isotipo.svg                  ← solo isotipo, color, fondo transparente
│   ├── cenit-lab-logo-horizontal.svg          ← lockup primario, texto tinta (fondo claro)
│   ├── cenit-lab-logo-horizontal-rev.svg      ← invertido, texto hueso (fondo oscuro)
│   ├── cenit-lab-logo-vertical.svg            ← lockup apilado + tagline mono
│   └── cenit-lab-app-icon.svg                 ← icono app, squircle índigo (autocontenido)
└── brandbook/
    └── cenit-lab-brandbook.html               ← manual de marca completo (responsive)
```

### Notas de los SVG
- El texto usa `font-family` + `@import` de Google Fonts → se ve correcto **en navegador**.
- Para máxima portabilidad (impresión, terceros), **convertir el texto a trazos/outlines** (ver TODO).
- El brandbook reutiliza el mark vía `<symbol>` + `<use>` y gradientes globales (`#z`, `#g`).
- Animación del hero respeta `prefers-reduced-motion`.

---

## 6. Reglas de uso (resumen)

- Área de protección: `x` = diámetro del punto cenit, en todos los lados. No invadir.
- Tamaño mínimo: 120 px ancho (digital) / 28 mm (impreso).
- Nunca: deformar, recolorear fuera de paleta, rotar (el cenit va arriba), agregar sombras/contornos,
  invadir el aire, ni poner el mark a color sobre fondos ruidosos (usar invertido o caja sólida).

---

## 7. Tono de voz
Claro (no técnico de más) · Confiado (no arrogante) · Humano (no frío) · Preciso (no vago).
La persona gestiona resultados, no “configura webhooks”. Ser específico > ser ingenioso.

---

## 8. TODO / próximos pasos
- [ ] **Outlines:** convertir el texto de los SVG a paths para versiones de producción/portables.
- [ ] **INAPI:** verificar disponibilidad de marca “Cenit Lab” en Chile antes de comprometer el nombre.
- [ ] **Color-code de unidades:** evaluar un matiz propio por unidad (AI/Data/Systems/Experience/Ventures).
- [ ] **Exports:** generar PNG/favicon/PWA icons (192, 512, maskable) desde `cenit-lab-app-icon.svg`.
- [ ] **Landing / web:** construir sitio con este sistema (mismo stack: Next.js + Vercel; o Framer).
- [ ] **Tailwind:** opcional, mapear tokens a `tailwind.config` si el proyecto lo usa.

---

## 9. Convenciones del proyecto (preferencias de Eduardo)
- Trabajo **incremental** con aprobación visual antes de cada paso; commits pequeños y verificables.
- Comentarios de código en **español**.
- **Mobile-first** (trabaja principalmente desde iPhone).
- Stack: EasyPanel, n8n, Framer, Dropbox, Notion, Supabase, Google Workspace, GHL, WaFlow,
  VS Code, Vercel, GitHub (`evaras-bit`), OpenAI, Anthropic (Claude / Claude Code).
