# Identidad — CenitLab

## Nombre

**Cenit Lab** (razón social **Cenit Lab SpA**; también escrito *CenitLab* / *CENIT LAB*).

## Qué es

**Cenit Lab** es un **estudio de ingeniería tecnológica** enfocado en **inteligencia
artificial, sistemas de datos y creación de nuevos negocios digitales**.

## Tagline

> **Designing the Future of Human–Machine Collaboration.**

## Propósito

Creemos que la próxima plataforma tecnológica no será una aplicación ni un dispositivo.

Será la **integración continua entre inteligencia humana e inteligencia artificial**.

Diseñamos sistemas que conectan **conocimiento, contexto y capacidad computacional**
para crear organizaciones más adaptativas, más rápidas y más inteligentes.

Construimos la **capa de inteligencia** sobre la cual operarán las empresas y personas
del futuro.

## Unidades de negocio

| Unidad | Qué hace |
|---|---|
| **Cenit Lab AI** | Agentes, LLMs, Machine Learning, Automation. |
| **Cenit Lab Data** | Data Platforms, Analytics, Warehousing, BI. |
| **Cenit Lab Systems** | Software, Apps, Integraciones, APIs, Infraestructura, **IoT / Edge / Hardware**. |
| **Cenit Lab Experience** | Customer Experience, Hospitality Tech, AI Interfaces. |
| **Cenit Lab Ventures** ⭐ | Incubación y creación de startups propias. **Es el core del estudio**: las demás unidades (AI, Data, Systems, Experience) son las capacidades con las que se construyen estos ventures. |

## Verticales de aplicación

Foco inicial de desarrollos: **hotelería premium** (proyectos de ML y domótica,
sobre todo en Cenit Lab AI / Experience).

## Sistema visual (creado)

La identidad visual ya está definida y vive en esta misma carpeta:

- **Manual de marca completo:** [`brandbook/cenit-lab-brandbook.html`](brandbook/cenit-lab-brandbook.html)
- **Sistema de marca y reglas de uso (contexto para Claude):** [`CLAUDE.md`](CLAUDE.md)
- **Logos (SVG):** [`logos/`](logos/) — isotipo, horizontal, horizontal invertido, vertical, app-icon
- **Design tokens (fuente de verdad):** [`design-tokens/tokens.css`](design-tokens/tokens.css) · [`design-tokens/tokens.json`](design-tokens/tokens.json)

Resumen rápido del sistema:

- **Isotipo:** "el punto cenit" — trazo oro (lo humano) + trazo azul estelar (la máquina) que convergen en un punto de luz. Metáfora del cisne: serenidad en la superficie, IA/ML por debajo.
- **Paleta:** Índigo Cenit `#0D1430` · Oro Cenit `#C6A35B` · Azul Estelar `#8FA8CE` · Hueso `#F4F1E9`.
- **Tipografía:** Space Grotesk (titulares/wordmark) · IBM Plex Sans (cuerpo) · IBM Plex Mono (datos/etiquetas).
- **Tono de voz:** claro · confiado · humano · preciso.

Pendientes menores (ver TODO en [`CLAUDE.md`](CLAUDE.md)): outlines de SVG para impresión, verificación INAPI del nombre, exports PNG/favicon/PWA.
